import React from 'react'


const Successpage = () => {
   
   
   
   
  return (
    <div>
       <h1>successfull payment</h1>
    </div>
  )
}

export default Successpage
